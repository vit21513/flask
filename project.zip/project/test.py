data = {
                'Выбранный элемент': "selected_option",
                'Имя Фамилия': "last_name",
                'Email адрес': "email",
                'Номер телефона': "phone",
                'Сообщение': "message",
                'Дата создания': "str(datetime.now())"
            }

print(str(data)[1:-1])

