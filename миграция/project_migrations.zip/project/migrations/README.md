# Работа с миграциями с помощью alembic

## 1. Установка библиотеки
```
pip install alembic
```
## 2. Настройка конфигурации alembic
```
alembic init migrations
```
В alembic.ini внести путь к бд
```
sqlalchemy.url = sqlite:///mydatabase.db
```
В env.py импортировать db для доступа к моделям SQLQlchemy
```
from models import db
# остальной код
target_metadata = db.Model.metadata
```
## 3. Создание миграции
```
alembic revision --autogenerate -m "initial migration"
```
## 4. Применение миграции
```
alembic upgrade head
```
## 5. Откат миграции
```
alembic downgrade -1
```